s1 = {1,45,6,8}
s2 = {7,8,1,45,90,4543}

print(s1.union(s2)) # returns a set that contains all items from both sets, duplicates are excluded
# {1, 6, 7, 8, 45, 90, 4543}

print(s1.intersection(s2)) # returns a set that contains all items that are present in both sets    

# {8,1, 45}
