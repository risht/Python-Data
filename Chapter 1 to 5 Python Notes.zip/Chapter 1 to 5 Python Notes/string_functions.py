name  = "roger are"

print(len(name))    # Output: 5 # length of the string

print(name.endswith("er"))    # Output: True # check if the string ends with "er"

print(name.startswith("R"))    # Output: False # check if the string starts with "r"

print(name.capitalize())    # Output: "Roger" # capitalize the first letter of the string, # Only starting character 

print(name.find("o"))    # Output: 1 # find the first occurrence of "o" in the string, returns the index of the first occurrence

name1 = "roger is good man"

print(name1.replace("roger","smith"))

