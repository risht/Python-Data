a = int(input("Enter the value of a :"))

b = int(input("Enter the value of b :"))

print("Check the value whether a is greater than b :",a >b)
