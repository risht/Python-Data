# set and dicitionary are being made using curly braces

e = set() # empty set

# d = {} # empty dictionary 

e1 = {1,5,7,5,5,7675,67575,8568}

print(e1, type(e1)) # (1, 5, 7, 5, 5, 7675, 67575, 8568) <class 'set'>

