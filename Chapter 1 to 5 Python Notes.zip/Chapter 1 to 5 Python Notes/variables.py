a = 1

b = 2

print(a+b)

b = "harry" # string

print(b)




