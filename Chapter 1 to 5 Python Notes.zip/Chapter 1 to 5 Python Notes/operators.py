a = 34
b = 5
#c = a+b
print(a+b)

# assignment operator
a = 4 -2 # assign 4-2 in a
print(a)
b = 6
b -=3 # increment the value of by 3 and then assign it to b

print(b) # 9

# Comparison operators(return boolean value true or false)

d = 5 >=5

print(d) #True

e  =  5==5

print(e) #True

# Logical Operators

print("True or False is ", True or False) 
print("True or False is ", True or False)
print("True or False is ", True or False)
print("True or False is ", True or False)

# AND 

"**************************" 

print("True and False is ", True and False) 
print("True and False is ", True and False)
print("True and False is ", True and False)
print("True and False is ", True and False)

print(not(True)) # False





