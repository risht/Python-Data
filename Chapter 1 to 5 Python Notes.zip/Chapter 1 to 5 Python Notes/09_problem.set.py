# the values enetered in set

s = {8, 7, 12, "Harry", [1,2]}

s[4][0] = 9

# cannot list in set
# cannot change the value using indexing
