name = "Robert"

nameshort = name[0:5] 

print(nameshort) # Output: "Rober" # start at index 0 and end at index 5 (not included)

char1 = name[1]

print(char1) # Output: "o" # index 1 is the second character in the string

# negative indexing starting from the end of the string -1,-2,-3,-4,-5

