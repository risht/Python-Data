d  = {}

name = input("Enter your name: ")
lan = input("Enter your language: ")

d.update({name: lan})

name = input("Enter your name: ")
lan = input("Enter your language: ")

d.update({name: lan})


name = input("Enter your name: ")
lan = input("Enter your language: ")

d.update({name: lan})


name = input("Enter your name: ")
lan = input("Enter your language: ")

d.update({name: lan})

print(d)
print("the key is: ", d.keys())
print("the value is: ", d.values())




