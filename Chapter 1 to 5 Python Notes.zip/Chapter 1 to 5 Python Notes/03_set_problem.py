s = set()

s.add(18)

s.add("18")

print(s) # {18, '18'}

