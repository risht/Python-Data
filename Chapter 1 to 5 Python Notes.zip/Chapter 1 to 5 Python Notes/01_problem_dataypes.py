a = 2

b = 5

print(a + b) # 7

