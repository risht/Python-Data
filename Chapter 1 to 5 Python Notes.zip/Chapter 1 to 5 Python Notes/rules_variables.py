a = 23

aaa = 435

harry = 34

_samer = 45

#@sameer = 56 # will not work 

#   @ dsa will not work

#s@meer # invalid due to @ symbol



