a = int(input("Enter the value of a :"))

print("The square of 2 numbers is :", a*a)

