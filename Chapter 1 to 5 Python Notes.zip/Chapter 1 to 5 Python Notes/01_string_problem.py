a = input("Enter your name: ")

print(f"Good Afternoon, {a} ")