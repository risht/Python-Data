name  = "Roger is a good  and  "

print(name.find("  ")) # find function return substring index to parent string

