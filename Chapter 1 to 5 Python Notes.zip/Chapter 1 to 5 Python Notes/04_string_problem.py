name  = "Roger is a good  and  "

print(name.replace("  "," ")) # to detect double space and replace with single space
print(name) # strings are immutable which means that you cannnot change them by executing or by running functions on them

