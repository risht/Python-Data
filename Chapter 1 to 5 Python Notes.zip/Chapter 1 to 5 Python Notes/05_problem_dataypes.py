a = int(input("Enter the value of a :"))

b = int(input("Enter the value of b :"))

print("The avergae of 2 numbers is :", (a+b)/2)

