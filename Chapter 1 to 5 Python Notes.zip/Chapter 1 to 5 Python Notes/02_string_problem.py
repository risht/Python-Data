letter = ''' Dear <|name|>,
YOU ARE SELECTED!
<Date|>'''

print(letter.replace("<|name|>", "Ravi").replace("<Date|>", "1st Sept 2025"))

# Output: Dear Ravi, YOU ARE SELECTED! 1st May 2023

