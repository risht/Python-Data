a = 31
t=type(a) # class <int>
print(t)

b = "31.2"

b = float(b)

t1 = type(b) # convert string to float

print(t1) #<class 'float'>

d = 31

d1 = float(d)

t2 = type(d1)

print(t2) #<class 'float'>



