a = int(input("Enter number 1: "))

b  = int(input("Enter number 2: "))

#print("Number a is: :", a)
#print("Number b is: :", b)


print("Sum is " , a + b)