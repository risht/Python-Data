
e1 = {1,5,7,5,5,7675,67575,8568,"hello","world"}

print(e1, type(e1)) # (1, 5, 7, 5, 5, 7675, 67575, 8568) <class 'set'>

e1.add(100) # adds 100 to the set

print(e1)

e1.remove(5)

print(e1,type(e1)) # {1, 7, 100, 7675, 67575, 8568} <class 'set'>



