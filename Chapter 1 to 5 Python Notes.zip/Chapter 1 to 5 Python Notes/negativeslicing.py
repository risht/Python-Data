name  = "Roger"

print(name[0:3])    # Output: "Rog" # start at index 0 and end at index 3 (not included)

print(name[0:-3])  # Output: "Ro" # start at index 0 and end at index -3 (not included)

print(name[-3:-1])    # Output: "ge" # start at index -3 and end at the end of the string

print(name[2:4])    # Same as name[-3:-1] # Output: "ge" # start at index 2 and end at index 4 (not included)

print(name[1:])   # Output: "oger" # start at index 1 and end at the end of the string
 
print(name[1:5])  # Output: "oger" # start at index 1 and end at index 5 (not included)
