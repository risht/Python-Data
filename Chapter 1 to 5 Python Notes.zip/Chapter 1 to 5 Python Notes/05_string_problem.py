letter  = "Dear Harry,\n\tthis python course is nice.\nThanks!"

print(letter)