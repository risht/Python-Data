from re import M


marks = { 
        "Hello": 100, 
          "World": 200, 
         "Python": 300, 
         "Programming": 450, 
         "Language": 500 }

#print(marks.items())    # returns a view object that displays a list of a dictionary's key-value tuple pairs 
# dict_items([('Hello', 100), ('World', 200), ('Python', 300), ('Programming', 450), ('Language', 500)])


# print(marks.keys()) # returns a view object that displays a list of all the keys in the dictionary

# dict_keys(['Hello', 'World', 'Python', 'Programming', 'Language'])

# left side ones displays the keys and right side ones displays the values

# print(marks.values()) # returns a view object that displays a list of all the values in the dictionary

# right side ones displays the values

# dict_keys(['Hello', 'World', 'Python', 'Programming', 'Language'])

marks.update({"Hello": 200, "Aditya": 800}) # updates the value of the key "Hello" to 200

print(marks) 

# {'Hello': 200, 'World': 200, 'Python': 300, 'Programming': 450, 'Language': 500}

# {'Hello': 200, 'World': 200, 'Python': 300, 'Programming': 450, 'Language': 500, 'Aditya': 800}

# print(marks.get(200)) # returns the value of the specified key "Hello" in the dictionary
# 200

# print(marks.get("Hello34")) # None
# print(marks["Hello34324"]) # KeyError: 'Hello34324'


