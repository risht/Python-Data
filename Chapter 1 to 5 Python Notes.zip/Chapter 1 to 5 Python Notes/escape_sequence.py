a  = "roger is good but not a bad man\n but he is\n excellent \tmight be"

b  = "roger is good but not a bad man\n but he is\t excellent might \"be\""

c = 'roger is good but not a bad man\n but he is\t excellent might \'be'

#print(a) # new line will be added

#print(b) 

print(c) # new line will be added