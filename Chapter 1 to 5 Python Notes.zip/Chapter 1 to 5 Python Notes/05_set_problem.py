s = {}

print(type(s)) # {} empty dictionary