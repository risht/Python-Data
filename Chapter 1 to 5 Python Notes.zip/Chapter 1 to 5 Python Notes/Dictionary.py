marks = { 
        "Hello": 100, 
          "World": 200, 
         "Python": 300, 
         "Programming": 450, 
         "Language": 500 }

#print(marks, type(marks))

print(marks["World"]) 


