my_dict   ={
    "madad": "help",
    "kursi": "chair",
    "kitab": "book",
    "pencil": "marker",
    }

d1 = input("Enter the word you want meaning of: ")

print (my_dict [d1]) # prints the meaning of the word entered by the user