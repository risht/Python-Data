s = set() # empty set

m = input("Enter number 1 : ")
s.add(int(m))

m = input("Enter number 1 : ")
s.add(int(m))

m = input("Enter number 1 : ")
s.add(int(m))

m = input("Enter number 1 : ")
s.add(int(m))

m = input("Enter number 1 : ")
s.add(int(m))

m = input("Enter number 1 : ")
s.add(int(m))


m = input("Enter number 1 : ")
s.add(int(m))

print(s)